/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/eventPage.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/eventPage.ts":
/*!**************************!*\
  !*** ./src/eventPage.ts ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Google Analytics bootstrap
(function (i, s, o, g, r, a, m) {
    i["GoogleAnalyticsObject"] = r;
    (i[r] =
        i[r] ||
            function () {
                (i[r].q = i[r].q || []).push(arguments);
            }),
        (i[r].l = 1 * Number(new Date()));
    (a = s.createElement(o)), (m = s.getElementsByTagName(o)[0]);
    a.async = 1;
    a.src = g;
    m.parentNode.insertBefore(a, m);
})(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
// @ts-ignore
ga("create", "UA-108017342-2", "auto");
// @ts-ignore
ga("set", "checkProtocolTask", function () { });
// @ts-ignore
ga("send", "pageview");
chrome.browserAction.setBadgeBackgroundColor({
    color: "#0078d4"
});
chrome.browserAction.setBadgeText({
    text: "ON"
});
// Listen to messages sent from other parts of the extension.
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // onMessage must return "true" if response is async.
    var isResponseAsync = false;
    if (request.contactDeveloper) {
        contactDeveloper();
    }
    else if (request.review) {
        review();
    }
    else if (request.makeBid) {
        trackEvent("makeBid");
    }
    else if (request.buyNow) {
        trackEvent("buyNow");
    }
    else if (request.buyBronzePack) {
        trackEvent("buyBronzePack");
    }
    else if (request.comparePrice) {
        trackEvent("comparePrice");
    }
    else if (request.decreaseMaxBidPrice) {
        trackEvent("decreaseMaxBidPrice");
    }
    else if (request.decreaseMinBidPrice) {
        trackEvent("decreaseMinBidPrice");
    }
    else if (request.increaseMaxBidPrice) {
        trackEvent("increaseMaxBidPrice");
    }
    else if (request.increaseMinBidPrice) {
        trackEvent("increaseMinBidPrice");
    }
    else if (request.listMinBin) {
        trackEvent("listMinBin");
    }
    else if (request.list) {
        trackEvent("list");
    }
    else if (request.quickSellAll) {
        trackEvent("quickSellAll");
    }
    else if (request.quickSell) {
        trackEvent("quickSell");
    }
    else if (request.search) {
        trackEvent("search");
        // Increment count of searches. Value is checked in Announcement component.
        chrome.storage.sync.get("searchCount", function (data) {
            var count = data.searchCount;
            // Initialize count if it doesn't exist, or increment if it does.
            var newCount;
            if (!count) {
                newCount = 1;
            }
            else {
                newCount = count + 1;
            }
            // Set the count.
            chrome.storage.sync.set({
                searchCount: newCount
            });
        });
    }
    else if (request.storeAllInClub) {
        trackEvent("storeAllInClub");
    }
    else if (request.storeInClub) {
        trackEvent("storeInClub");
    }
    else if (request.watch) {
        trackEvent("watch");
    }
    else if (request.sendToTransferList) {
        trackEvent("sendToTransferList");
    }
    else if (request.warningDismissed) {
        chrome.storage.sync.get("warningCount", function (data) {
            if (data.warningCount === 1) {
                trackEvent("firstWarningDismissed");
            }
            else {
                trackEvent("warningDismissed");
            }
        });
    }
    else if (request.warningShown) {
        chrome.storage.sync.get("warningCount", function (data) {
            if (!data.warningCount) {
                chrome.storage.sync.set({
                    warningCount: 1
                });
                trackEvent("firstWarningShown");
            }
            else {
                chrome.storage.sync.set({
                    warningCount: data.warningCount + 1
                });
                trackEvent("warningShown");
            }
        });
    }
    else if (request.logEmailAddress) {
        chrome.identity.getProfileUserInfo(function (userInfo) {
            console.log("User email address: " + (userInfo.email || "NOT AVAILABLE"));
        });
    }
    return isResponseAsync;
});
/**
 * This function hits the mailto protocol and returns user to current tab.
 */
function contactDeveloper() {
    chrome.tabs.query({
        active: true
    }, function (tabs) {
        // Caches current user tab so we can return to it.
        var currentTabId = tabs[0].id;
        chrome.tabs.create({
            active: true,
            url: "mailto:shortfuts@gmail.com?subject=shortfuts%20feedback"
        }, function (mailToTab) {
            setTimeout(function () {
                // Closes tab created by mailto protocol.
                chrome.tabs.remove(mailToTab.id);
                // Makes previously focused tab selected.
                chrome.tabs.update(currentTabId, {
                    highlighted: true
                });
            }, 150);
        });
    });
}
/**
 * Opens Chrome Web Store page so user can review.
 */
function review() {
    chrome.tabs.create({
        active: true,
        url: "https://chrome.google.com/webstore/detail/shortfuts/piepdojghinggmddebidfkhfbdaggnmh"
    });
}
function trackEvent(eventName) {
    // @ts-ignore
    ga("send", {
        hitType: "event",
        eventCategory: "telemetry",
        eventAction: eventName
    });
}


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2V2ZW50UGFnZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7QUFDQSx5REFBaUQsY0FBYztBQUMvRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBMkIsMEJBQTBCLEVBQUU7QUFDdkQseUNBQWlDLGVBQWU7QUFDaEQ7QUFDQTtBQUNBOztBQUVBO0FBQ0EsOERBQXNELCtEQUErRDs7QUFFckg7QUFDQTs7O0FBR0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDbkVBLDZCQUE2QjtBQUM3QixDQUFDLFVBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztJQUN6QixDQUFDLENBQUMsdUJBQXVCLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ0QsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNKO2dCQUNJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUM1QyxDQUFDLENBQUM7UUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztJQUN0QyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDN0QsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7SUFDWixDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUNWLENBQUMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FDRSxNQUFNLEVBQ04sUUFBUSxFQUNSLFFBQVEsRUFDUiwrQ0FBK0MsRUFDL0MsSUFBSSxDQUNQLENBQUM7QUFFRixhQUFhO0FBQ2IsRUFBRSxDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUN2QyxhQUFhO0FBQ2IsRUFBRSxDQUFDLEtBQUssRUFBRSxtQkFBbUIsRUFBRSxjQUFZLENBQUMsQ0FBQyxDQUFDO0FBQzlDLGFBQWE7QUFDYixFQUFFLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBRXZCLE1BQU0sQ0FBQyxhQUFhLENBQUMsdUJBQXVCLENBQUM7SUFDekMsS0FBSyxFQUFFLFNBQVM7Q0FDbkIsQ0FBQyxDQUFDO0FBQ0gsTUFBTSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUM7SUFDOUIsSUFBSSxFQUFFLElBQUk7Q0FDYixDQUFDLENBQUM7QUFFSCw2REFBNkQ7QUFDN0QsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxZQUFZO0lBQy9ELHFEQUFxRDtJQUNyRCxJQUFJLGVBQWUsR0FBRyxLQUFLLENBQUM7SUFFNUIsSUFBSSxPQUFPLENBQUMsZ0JBQWdCLEVBQUU7UUFDMUIsZ0JBQWdCLEVBQUUsQ0FBQztLQUN0QjtTQUFNLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtRQUN2QixNQUFNLEVBQUUsQ0FBQztLQUNaO1NBQU0sSUFBSSxPQUFPLENBQUMsT0FBTyxFQUFFO1FBQ3hCLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztLQUN6QjtTQUFNLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtRQUN2QixVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7S0FDeEI7U0FBTSxJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUU7UUFDOUIsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0tBQy9CO1NBQU0sSUFBSSxPQUFPLENBQUMsWUFBWSxFQUFFO1FBQzdCLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztLQUM5QjtTQUFNLElBQUksT0FBTyxDQUFDLG1CQUFtQixFQUFFO1FBQ3BDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0tBQ3JDO1NBQU0sSUFBSSxPQUFPLENBQUMsbUJBQW1CLEVBQUU7UUFDcEMsVUFBVSxDQUFDLHFCQUFxQixDQUFDLENBQUM7S0FDckM7U0FBTSxJQUFJLE9BQU8sQ0FBQyxtQkFBbUIsRUFBRTtRQUNwQyxVQUFVLENBQUMscUJBQXFCLENBQUMsQ0FBQztLQUNyQztTQUFNLElBQUksT0FBTyxDQUFDLG1CQUFtQixFQUFFO1FBQ3BDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0tBQ3JDO1NBQU0sSUFBSSxPQUFPLENBQUMsVUFBVSxFQUFFO1FBQzNCLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztLQUM1QjtTQUFNLElBQUksT0FBTyxDQUFDLElBQUksRUFBRTtRQUNyQixVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7S0FDdEI7U0FBTSxJQUFJLE9BQU8sQ0FBQyxZQUFZLEVBQUU7UUFDN0IsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0tBQzlCO1NBQU0sSUFBSSxPQUFPLENBQUMsU0FBUyxFQUFFO1FBQzFCLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztLQUMzQjtTQUFNLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtRQUN2QixVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFckIsMkVBQTJFO1FBQzNFLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsY0FBSTtZQUN2QyxJQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1lBRS9CLGlFQUFpRTtZQUNqRSxJQUFJLFFBQVEsQ0FBQztZQUNiLElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ1IsUUFBUSxHQUFHLENBQUMsQ0FBQzthQUNoQjtpQkFBTTtnQkFDSCxRQUFRLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQzthQUN4QjtZQUVELGlCQUFpQjtZQUNqQixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQ3BCLFdBQVcsRUFBRSxRQUFRO2FBQ3hCLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0tBQ047U0FBTSxJQUFJLE9BQU8sQ0FBQyxjQUFjLEVBQUU7UUFDL0IsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7S0FDaEM7U0FBTSxJQUFJLE9BQU8sQ0FBQyxXQUFXLEVBQUU7UUFDNUIsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0tBQzdCO1NBQU0sSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFO1FBQ3RCLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUN2QjtTQUFNLElBQUksT0FBTyxDQUFDLGtCQUFrQixFQUFFO1FBQ25DLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0tBQ3BDO1NBQU0sSUFBSSxPQUFPLENBQUMsZ0JBQWdCLEVBQUU7UUFDakMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBRSxjQUFJO1lBQ3hDLElBQUksSUFBSSxDQUFDLFlBQVksS0FBSyxDQUFDLEVBQUU7Z0JBQ3pCLFVBQVUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO2FBQ3ZDO2lCQUFNO2dCQUNILFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2FBQ2xDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7S0FDTjtTQUFNLElBQUksT0FBTyxDQUFDLFlBQVksRUFBRTtRQUM3QixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLGNBQUk7WUFDeEMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQ3BCLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztvQkFDcEIsWUFBWSxFQUFFLENBQUM7aUJBQ2xCLENBQUMsQ0FBQztnQkFFSCxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQzthQUNuQztpQkFBTTtnQkFDSCxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7b0JBQ3BCLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWSxHQUFHLENBQUM7aUJBQ3RDLENBQUMsQ0FBQztnQkFFSCxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7YUFDOUI7UUFDTCxDQUFDLENBQUMsQ0FBQztLQUNOO1NBQU0sSUFBSSxPQUFPLENBQUMsZUFBZSxFQUFFO1FBQ2hDLE1BQU0sQ0FBQyxRQUFRLENBQUMsa0JBQWtCLENBQUMsa0JBQVE7WUFDdkMsT0FBTyxDQUFDLEdBQUcsQ0FDUCwwQkFBdUIsUUFBUSxDQUFDLEtBQUssSUFBSSxlQUFlLENBQUUsQ0FDN0QsQ0FBQztRQUNOLENBQUMsQ0FBQyxDQUFDO0tBQ047SUFFRCxPQUFPLGVBQWUsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQztBQUVIOztHQUVHO0FBQ0g7SUFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FDYjtRQUNJLE1BQU0sRUFBRSxJQUFJO0tBQ2YsRUFDRCxjQUFJO1FBQ0Esa0RBQWtEO1FBQ2xELElBQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFFaEMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQ2Q7WUFDSSxNQUFNLEVBQUUsSUFBSTtZQUNaLEdBQUcsRUFDQyx5REFBeUQ7U0FDaEUsRUFDRCxtQkFBUztZQUNMLFVBQVUsQ0FBQztnQkFDUCx5Q0FBeUM7Z0JBQ3pDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFFakMseUNBQXlDO2dCQUN6QyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUU7b0JBQzdCLFdBQVcsRUFBRSxJQUFJO2lCQUNwQixDQUFDLENBQUM7WUFDUCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDWixDQUFDLENBQ0osQ0FBQztJQUNOLENBQUMsQ0FDSixDQUFDO0FBQ04sQ0FBQztBQUVEOztHQUVHO0FBQ0g7SUFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNmLE1BQU0sRUFBRSxJQUFJO1FBQ1osR0FBRyxFQUNDLHNGQUFzRjtLQUM3RixDQUFDLENBQUM7QUFDUCxDQUFDO0FBRUQsb0JBQW9CLFNBQWlCO0lBQ2pDLGFBQWE7SUFDYixFQUFFLENBQUMsTUFBTSxFQUFFO1FBQ1AsT0FBTyxFQUFFLE9BQU87UUFDaEIsYUFBYSxFQUFFLFdBQVc7UUFDMUIsV0FBVyxFQUFFLFNBQVM7S0FDekIsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyIsImZpbGUiOiJldmVudFBhZ2UuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHtcbiBcdFx0XHRcdGNvbmZpZ3VyYWJsZTogZmFsc2UsXG4gXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuIFx0XHRcdFx0Z2V0OiBnZXR0ZXJcbiBcdFx0XHR9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9zcmMvZXZlbnRQYWdlLnRzXCIpO1xuIiwiLy8gR29vZ2xlIEFuYWx5dGljcyBib290c3RyYXBcbihmdW5jdGlvbihpLCBzLCBvLCBnLCByLCBhLCBtKSB7XG4gICAgaVtcIkdvb2dsZUFuYWx5dGljc09iamVjdFwiXSA9IHI7XG4gICAgKGlbcl0gPVxuICAgICAgICBpW3JdIHx8XG4gICAgICAgIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgKGlbcl0ucSA9IGlbcl0ucSB8fCBbXSkucHVzaChhcmd1bWVudHMpO1xuICAgICAgICB9KSxcbiAgICAgICAgKGlbcl0ubCA9IDEgKiBOdW1iZXIobmV3IERhdGUoKSkpO1xuICAgIChhID0gcy5jcmVhdGVFbGVtZW50KG8pKSwgKG0gPSBzLmdldEVsZW1lbnRzQnlUYWdOYW1lKG8pWzBdKTtcbiAgICBhLmFzeW5jID0gMTtcbiAgICBhLnNyYyA9IGc7XG4gICAgbS5wYXJlbnROb2RlLmluc2VydEJlZm9yZShhLCBtKTtcbn0pKFxuICAgIHdpbmRvdyxcbiAgICBkb2N1bWVudCxcbiAgICBcInNjcmlwdFwiLFxuICAgIFwiaHR0cHM6Ly93d3cuZ29vZ2xlLWFuYWx5dGljcy5jb20vYW5hbHl0aWNzLmpzXCIsXG4gICAgXCJnYVwiXG4pO1xuXG4vLyBAdHMtaWdub3JlXG5nYShcImNyZWF0ZVwiLCBcIlVBLTEwODAxNzM0Mi0yXCIsIFwiYXV0b1wiKTtcbi8vIEB0cy1pZ25vcmVcbmdhKFwic2V0XCIsIFwiY2hlY2tQcm90b2NvbFRhc2tcIiwgZnVuY3Rpb24oKSB7fSk7XG4vLyBAdHMtaWdub3JlXG5nYShcInNlbmRcIiwgXCJwYWdldmlld1wiKTtcblxuY2hyb21lLmJyb3dzZXJBY3Rpb24uc2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3Ioe1xuICAgIGNvbG9yOiBcIiMwMDc4ZDRcIlxufSk7XG5jaHJvbWUuYnJvd3NlckFjdGlvbi5zZXRCYWRnZVRleHQoe1xuICAgIHRleHQ6IFwiT05cIlxufSk7XG5cbi8vIExpc3RlbiB0byBtZXNzYWdlcyBzZW50IGZyb20gb3RoZXIgcGFydHMgb2YgdGhlIGV4dGVuc2lvbi5cbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigocmVxdWVzdCwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcbiAgICAvLyBvbk1lc3NhZ2UgbXVzdCByZXR1cm4gXCJ0cnVlXCIgaWYgcmVzcG9uc2UgaXMgYXN5bmMuXG4gICAgbGV0IGlzUmVzcG9uc2VBc3luYyA9IGZhbHNlO1xuXG4gICAgaWYgKHJlcXVlc3QuY29udGFjdERldmVsb3Blcikge1xuICAgICAgICBjb250YWN0RGV2ZWxvcGVyKCk7XG4gICAgfSBlbHNlIGlmIChyZXF1ZXN0LnJldmlldykge1xuICAgICAgICByZXZpZXcoKTtcbiAgICB9IGVsc2UgaWYgKHJlcXVlc3QubWFrZUJpZCkge1xuICAgICAgICB0cmFja0V2ZW50KFwibWFrZUJpZFwiKTtcbiAgICB9IGVsc2UgaWYgKHJlcXVlc3QuYnV5Tm93KSB7XG4gICAgICAgIHRyYWNrRXZlbnQoXCJidXlOb3dcIik7XG4gICAgfSBlbHNlIGlmIChyZXF1ZXN0LmJ1eUJyb256ZVBhY2spIHtcbiAgICAgICAgdHJhY2tFdmVudChcImJ1eUJyb256ZVBhY2tcIik7XG4gICAgfSBlbHNlIGlmIChyZXF1ZXN0LmNvbXBhcmVQcmljZSkge1xuICAgICAgICB0cmFja0V2ZW50KFwiY29tcGFyZVByaWNlXCIpO1xuICAgIH0gZWxzZSBpZiAocmVxdWVzdC5kZWNyZWFzZU1heEJpZFByaWNlKSB7XG4gICAgICAgIHRyYWNrRXZlbnQoXCJkZWNyZWFzZU1heEJpZFByaWNlXCIpO1xuICAgIH0gZWxzZSBpZiAocmVxdWVzdC5kZWNyZWFzZU1pbkJpZFByaWNlKSB7XG4gICAgICAgIHRyYWNrRXZlbnQoXCJkZWNyZWFzZU1pbkJpZFByaWNlXCIpO1xuICAgIH0gZWxzZSBpZiAocmVxdWVzdC5pbmNyZWFzZU1heEJpZFByaWNlKSB7XG4gICAgICAgIHRyYWNrRXZlbnQoXCJpbmNyZWFzZU1heEJpZFByaWNlXCIpO1xuICAgIH0gZWxzZSBpZiAocmVxdWVzdC5pbmNyZWFzZU1pbkJpZFByaWNlKSB7XG4gICAgICAgIHRyYWNrRXZlbnQoXCJpbmNyZWFzZU1pbkJpZFByaWNlXCIpO1xuICAgIH0gZWxzZSBpZiAocmVxdWVzdC5saXN0TWluQmluKSB7XG4gICAgICAgIHRyYWNrRXZlbnQoXCJsaXN0TWluQmluXCIpO1xuICAgIH0gZWxzZSBpZiAocmVxdWVzdC5saXN0KSB7XG4gICAgICAgIHRyYWNrRXZlbnQoXCJsaXN0XCIpO1xuICAgIH0gZWxzZSBpZiAocmVxdWVzdC5xdWlja1NlbGxBbGwpIHtcbiAgICAgICAgdHJhY2tFdmVudChcInF1aWNrU2VsbEFsbFwiKTtcbiAgICB9IGVsc2UgaWYgKHJlcXVlc3QucXVpY2tTZWxsKSB7XG4gICAgICAgIHRyYWNrRXZlbnQoXCJxdWlja1NlbGxcIik7XG4gICAgfSBlbHNlIGlmIChyZXF1ZXN0LnNlYXJjaCkge1xuICAgICAgICB0cmFja0V2ZW50KFwic2VhcmNoXCIpO1xuXG4gICAgICAgIC8vIEluY3JlbWVudCBjb3VudCBvZiBzZWFyY2hlcy4gVmFsdWUgaXMgY2hlY2tlZCBpbiBBbm5vdW5jZW1lbnQgY29tcG9uZW50LlxuICAgICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldChcInNlYXJjaENvdW50XCIsIGRhdGEgPT4ge1xuICAgICAgICAgICAgY29uc3QgY291bnQgPSBkYXRhLnNlYXJjaENvdW50O1xuXG4gICAgICAgICAgICAvLyBJbml0aWFsaXplIGNvdW50IGlmIGl0IGRvZXNuJ3QgZXhpc3QsIG9yIGluY3JlbWVudCBpZiBpdCBkb2VzLlxuICAgICAgICAgICAgbGV0IG5ld0NvdW50O1xuICAgICAgICAgICAgaWYgKCFjb3VudCkge1xuICAgICAgICAgICAgICAgIG5ld0NvdW50ID0gMTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbmV3Q291bnQgPSBjb3VudCArIDE7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIFNldCB0aGUgY291bnQuXG4gICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLnNldCh7XG4gICAgICAgICAgICAgICAgc2VhcmNoQ291bnQ6IG5ld0NvdW50XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfSBlbHNlIGlmIChyZXF1ZXN0LnN0b3JlQWxsSW5DbHViKSB7XG4gICAgICAgIHRyYWNrRXZlbnQoXCJzdG9yZUFsbEluQ2x1YlwiKTtcbiAgICB9IGVsc2UgaWYgKHJlcXVlc3Quc3RvcmVJbkNsdWIpIHtcbiAgICAgICAgdHJhY2tFdmVudChcInN0b3JlSW5DbHViXCIpO1xuICAgIH0gZWxzZSBpZiAocmVxdWVzdC53YXRjaCkge1xuICAgICAgICB0cmFja0V2ZW50KFwid2F0Y2hcIik7XG4gICAgfSBlbHNlIGlmIChyZXF1ZXN0LnNlbmRUb1RyYW5zZmVyTGlzdCkge1xuICAgICAgICB0cmFja0V2ZW50KFwic2VuZFRvVHJhbnNmZXJMaXN0XCIpO1xuICAgIH0gZWxzZSBpZiAocmVxdWVzdC53YXJuaW5nRGlzbWlzc2VkKSB7XG4gICAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFwid2FybmluZ0NvdW50XCIsIGRhdGEgPT4ge1xuICAgICAgICAgICAgaWYgKGRhdGEud2FybmluZ0NvdW50ID09PSAxKSB7XG4gICAgICAgICAgICAgICAgdHJhY2tFdmVudChcImZpcnN0V2FybmluZ0Rpc21pc3NlZFwiKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdHJhY2tFdmVudChcIndhcm5pbmdEaXNtaXNzZWRcIik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAocmVxdWVzdC53YXJuaW5nU2hvd24pIHtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXCJ3YXJuaW5nQ291bnRcIiwgZGF0YSA9PiB7XG4gICAgICAgICAgICBpZiAoIWRhdGEud2FybmluZ0NvdW50KSB7XG4gICAgICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoe1xuICAgICAgICAgICAgICAgICAgICB3YXJuaW5nQ291bnQ6IDFcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIHRyYWNrRXZlbnQoXCJmaXJzdFdhcm5pbmdTaG93blwiKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoe1xuICAgICAgICAgICAgICAgICAgICB3YXJuaW5nQ291bnQ6IGRhdGEud2FybmluZ0NvdW50ICsgMVxuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgdHJhY2tFdmVudChcIndhcm5pbmdTaG93blwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSBlbHNlIGlmIChyZXF1ZXN0LmxvZ0VtYWlsQWRkcmVzcykge1xuICAgICAgICBjaHJvbWUuaWRlbnRpdHkuZ2V0UHJvZmlsZVVzZXJJbmZvKHVzZXJJbmZvID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICAgIGBVc2VyIGVtYWlsIGFkZHJlc3M6ICR7dXNlckluZm8uZW1haWwgfHwgXCJOT1QgQVZBSUxBQkxFXCJ9YFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGlzUmVzcG9uc2VBc3luYztcbn0pO1xuXG4vKipcbiAqIFRoaXMgZnVuY3Rpb24gaGl0cyB0aGUgbWFpbHRvIHByb3RvY29sIGFuZCByZXR1cm5zIHVzZXIgdG8gY3VycmVudCB0YWIuXG4gKi9cbmZ1bmN0aW9uIGNvbnRhY3REZXZlbG9wZXIoKSB7XG4gICAgY2hyb21lLnRhYnMucXVlcnkoXG4gICAgICAgIHtcbiAgICAgICAgICAgIGFjdGl2ZTogdHJ1ZVxuICAgICAgICB9LFxuICAgICAgICB0YWJzID0+IHtcbiAgICAgICAgICAgIC8vIENhY2hlcyBjdXJyZW50IHVzZXIgdGFiIHNvIHdlIGNhbiByZXR1cm4gdG8gaXQuXG4gICAgICAgICAgICBjb25zdCBjdXJyZW50VGFiSWQgPSB0YWJzWzBdLmlkO1xuXG4gICAgICAgICAgICBjaHJvbWUudGFicy5jcmVhdGUoXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBhY3RpdmU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIHVybDpcbiAgICAgICAgICAgICAgICAgICAgICAgIFwibWFpbHRvOnNob3J0ZnV0c0BnbWFpbC5jb20/c3ViamVjdD1zaG9ydGZ1dHMlMjBmZWVkYmFja1wiXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBtYWlsVG9UYWIgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ2xvc2VzIHRhYiBjcmVhdGVkIGJ5IG1haWx0byBwcm90b2NvbC5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNocm9tZS50YWJzLnJlbW92ZShtYWlsVG9UYWIuaWQpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBNYWtlcyBwcmV2aW91c2x5IGZvY3VzZWQgdGFiIHNlbGVjdGVkLlxuICAgICAgICAgICAgICAgICAgICAgICAgY2hyb21lLnRhYnMudXBkYXRlKGN1cnJlbnRUYWJJZCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhpZ2hsaWdodGVkOiB0cnVlXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfSwgMTUwKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgKTtcbn1cblxuLyoqXG4gKiBPcGVucyBDaHJvbWUgV2ViIFN0b3JlIHBhZ2Ugc28gdXNlciBjYW4gcmV2aWV3LlxuICovXG5mdW5jdGlvbiByZXZpZXcoKSB7XG4gICAgY2hyb21lLnRhYnMuY3JlYXRlKHtcbiAgICAgICAgYWN0aXZlOiB0cnVlLFxuICAgICAgICB1cmw6XG4gICAgICAgICAgICBcImh0dHBzOi8vY2hyb21lLmdvb2dsZS5jb20vd2Vic3RvcmUvZGV0YWlsL3Nob3J0ZnV0cy9waWVwZG9qZ2hpbmdnbWRkZWJpZGZraGZiZGFnZ25taFwiXG4gICAgfSk7XG59XG5cbmZ1bmN0aW9uIHRyYWNrRXZlbnQoZXZlbnROYW1lOiBzdHJpbmcpIHtcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgZ2EoXCJzZW5kXCIsIHtcbiAgICAgICAgaGl0VHlwZTogXCJldmVudFwiLFxuICAgICAgICBldmVudENhdGVnb3J5OiBcInRlbGVtZXRyeVwiLFxuICAgICAgICBldmVudEFjdGlvbjogZXZlbnROYW1lXG4gICAgfSk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9